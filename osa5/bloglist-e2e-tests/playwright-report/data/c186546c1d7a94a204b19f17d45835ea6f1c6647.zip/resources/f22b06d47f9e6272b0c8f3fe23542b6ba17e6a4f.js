import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Footer.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c26996b2"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Footer.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const Footer = () => {
  const footerStyle = {
    color: "green",
    fontStyle: "italic",
    fontSize: 16
  };
  return /* @__PURE__ */ jsxDEV("div", { style: footerStyle, children: [
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Footer.jsx",
      lineNumber: 29,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("em", { children: "Blog App A!" }, void 0, false, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Footer.jsx",
      lineNumber: 30,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Footer.jsx",
    lineNumber: 28,
    columnNumber: 5
  }, this);
};
_c = Footer;
export default Footer;
var _c;
$RefreshReg$(_c, "Footer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Footer.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Footer.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007Ozs7Ozs7Ozs7Ozs7Ozs7QUFUTixNQUFNQSxTQUFTQSxNQUFNO0FBQ25CLFFBQU1DLGNBQWM7QUFBQSxJQUNsQkMsT0FBTztBQUFBLElBQ1BDLFdBQVc7QUFBQSxJQUNYQyxVQUFVO0FBQUEsRUFDWjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxPQUFPSCxhQUNWO0FBQUEsMkJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUNILHVCQUFDLFFBQUcsMkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsT0FGakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBO0FBRUo7QUFBQ0ksS0FiS0w7QUFlTixlQUFlQTtBQUFNLElBQUFLO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJGb290ZXIiLCJmb290ZXJTdHlsZSIsImNvbG9yIiwiZm9udFN0eWxlIiwiZm9udFNpemUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkZvb3Rlci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgRm9vdGVyID0gKCkgPT4ge1xuICBjb25zdCBmb290ZXJTdHlsZSA9IHtcbiAgICBjb2xvcjogJ2dyZWVuJyxcbiAgICBmb250U3R5bGU6ICdpdGFsaWMnLFxuICAgIGZvbnRTaXplOiAxNlxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHN0eWxlPXtmb290ZXJTdHlsZX0+XG4gICAgICA8YnIgLz5cbiAgICAgIDxlbT5CbG9nIEFwcCBBITwvZW0+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgRm9vdGVyIl0sImZpbGUiOiIvVXNlcnMvYXJ2by9mdWxsc3RhY2svb3NhNS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Gb290ZXIuanN4In0=