import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c26996b2"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Notification.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const Notification = ({ message }) => {
  if (message === null) {
    return null;
  }
  if (message.includes("added")) {
    return /* @__PURE__ */ jsxDEV("div", { className: "success", children: message }, void 0, false, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Notification.jsx",
      lineNumber: 26,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "error", children: message }, void 0, false, {
    fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Notification.jsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
};
_c = Notification;
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Notification.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTU07Ozs7Ozs7Ozs7Ozs7Ozs7QUFOTixNQUFNQSxlQUFlQSxDQUFDLEVBQUVDLFFBQVEsTUFBTTtBQUNwQyxNQUFJQSxZQUFZLE1BQU07QUFDcEIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxNQUFJQSxRQUFRQyxTQUFTLE9BQU8sR0FBRztBQUM3QixXQUNFLHVCQUFDLFNBQUksV0FBVSxXQUNaRCxxQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBQ0EsU0FDRSx1QkFBQyxTQUFJLFdBQVUsU0FDWkEscUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBQ0UsS0FoQktIO0FBa0JOLGVBQWVBO0FBQVksSUFBQUc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk5vdGlmaWNhdGlvbiIsIm1lc3NhZ2UiLCJpbmNsdWRlcyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTm90aWZpY2F0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBOb3RpZmljYXRpb24gPSAoeyBtZXNzYWdlIH0pID0+IHtcbiAgaWYgKG1lc3NhZ2UgPT09IG51bGwpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG4gIGlmIChtZXNzYWdlLmluY2x1ZGVzKCdhZGRlZCcpKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VjY2Vzc1wiPlxuICAgICAgICB7bWVzc2FnZX1cbiAgICAgIDwvZGl2PlxuICAgIClcbiAgfVxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZXJyb3JcIj5cbiAgICAgIHttZXNzYWdlfVxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IE5vdGlmaWNhdGlvbiJdLCJmaWxlIjoiL1VzZXJzL2Fydm8vZnVsbHN0YWNrL29zYTUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uLmpzeCJ9