import {
  require_react
} from "/node_modules/.vite/deps/chunk-7JGOPB4S.js?v=c26996b2";
import "/node_modules/.vite/deps/chunk-6TJCVOLN.js?v=c26996b2";
export default require_react();
//# sourceMappingURL=react.js.map
