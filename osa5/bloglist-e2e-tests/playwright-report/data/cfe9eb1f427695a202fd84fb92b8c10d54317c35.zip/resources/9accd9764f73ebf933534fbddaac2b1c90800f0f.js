import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c26996b2"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/BlogForm.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=c26996b2"; const useState = __vite__cjsImport3_react["useState"];
const BlogForm = ({ createBlog }) => {
  _s();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const addBlog = (event) => {
    event.preventDefault();
    createBlog({
      title,
      author,
      url
    });
    setTitle("");
    setAuthor("");
    setUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "formDiv", children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "create new" }, void 0, false, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 40,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: addBlog, children: [
      "title:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: title,
          onChange: ({ target }) => setTitle(target.value),
          "data-testid": "title-input",
          placeholder: "title:"
        },
        void 0,
        false,
        {
          fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 43,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 48,
        columnNumber: 9
      }, this),
      "author:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: author,
          onChange: ({ target }) => setAuthor(target.value),
          "data-testid": "author-input",
          placeholder: "author:"
        },
        void 0,
        false,
        {
          fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 50,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 55,
        columnNumber: 9
      }, this),
      "url:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: url,
          onChange: ({ target }) => setUrl(target.value),
          "data-testid": "url-input",
          placeholder: "url:"
        },
        void 0,
        false,
        {
          fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 57,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "create" }, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/BlogForm.jsx",
        lineNumber: 63,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 41,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/BlogForm.jsx",
    lineNumber: 39,
    columnNumber: 5
  }, this);
};
_s(BlogForm, "g+g+3j1LiFjJCP23+NliFDHOHt4=");
_c = BlogForm;
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/BlogForm.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBCTixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsV0FBV0EsQ0FBQyxFQUFFQyxXQUFXLE1BQU07QUFBQUMsS0FBQTtBQUNuQyxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSUwsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ00sUUFBUUMsU0FBUyxJQUFJUCxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDUSxLQUFLQyxNQUFNLElBQUlULFNBQVMsRUFBRTtBQUNqQyxRQUFNVSxVQUFVQSxDQUFDQyxVQUFVO0FBQ3pCQSxVQUFNQyxlQUFlO0FBQ3JCVixlQUFXO0FBQUEsTUFDVEU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsSUFDRixDQUFDO0FBRURILGFBQVMsRUFBRTtBQUNYRSxjQUFVLEVBQUU7QUFDWkUsV0FBTyxFQUFFO0FBQUEsRUFDWDtBQUNBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSwyQkFBQyxRQUFHLDBCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYztBQUFBLElBQ2QsdUJBQUMsVUFBSyxVQUFVQyxTQUFRO0FBQUE7QUFBQSxNQUV0QjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsT0FBT047QUFBQUEsVUFDUCxVQUFVLENBQUMsRUFBRVMsT0FBTyxNQUFNUixTQUFTUSxPQUFPQyxLQUFLO0FBQUEsVUFDL0MsZUFBWTtBQUFBLFVBQWMsYUFBWTtBQUFBO0FBQUEsUUFKeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSWdEO0FBQUEsTUFDOUMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQTtBQUFBLE1BRUw7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE9BQU9SO0FBQUFBLFVBQ1AsVUFBVSxDQUFDLEVBQUVPLE9BQU8sTUFBTU4sVUFBVU0sT0FBT0MsS0FBSztBQUFBLFVBQ2hELGVBQVk7QUFBQSxVQUFlLGFBQVk7QUFBQTtBQUFBLFFBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlrRDtBQUFBLE1BQ2hELHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUE7QUFBQSxNQUVMO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPTjtBQUFBQSxVQUNQLFVBQVUsQ0FBQyxFQUFFSyxPQUFPLE1BQU1KLE9BQU9JLE9BQU9DLEtBQUs7QUFBQSxVQUM3QyxlQUFZO0FBQUEsVUFBWSxhQUFZO0FBQUE7QUFBQSxRQUp0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJNEM7QUFBQSxNQUU1Qyx1QkFBQyxZQUFPLE1BQUssVUFBUyxzQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QjtBQUFBLFNBdEI5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsT0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBCQTtBQUVKO0FBQUNYLEdBN0NLRixVQUFRO0FBQUFjLEtBQVJkO0FBK0NOLGVBQWVBO0FBQVEsSUFBQWM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQmxvZ0Zvcm0iLCJjcmVhdGVCbG9nIiwiX3MiLCJ0aXRsZSIsInNldFRpdGxlIiwiYXV0aG9yIiwic2V0QXV0aG9yIiwidXJsIiwic2V0VXJsIiwiYWRkQmxvZyIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmxvZ0Zvcm0uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5cbmNvbnN0IEJsb2dGb3JtID0gKHsgY3JlYXRlQmxvZyB9KSA9PiB7XG4gIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFthdXRob3IsIHNldEF1dGhvcl0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3VybCwgc2V0VXJsXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBhZGRCbG9nID0gKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgIGNyZWF0ZUJsb2coe1xuICAgICAgdGl0bGU6IHRpdGxlLFxuICAgICAgYXV0aG9yOiBhdXRob3IsXG4gICAgICB1cmw6IHVybFxuICAgIH0pXG5cbiAgICBzZXRUaXRsZSgnJylcbiAgICBzZXRBdXRob3IoJycpXG4gICAgc2V0VXJsKCcnKVxuICB9XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtRGl2XCI+XG4gICAgICA8aDI+Y3JlYXRlIG5ldzwvaDI+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17YWRkQmxvZ30+XG4gICAgICAgICAgICB0aXRsZTpcbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgIHZhbHVlPXt0aXRsZX1cbiAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFRpdGxlKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgZGF0YS10ZXN0aWQ9J3RpdGxlLWlucHV0JyBwbGFjZWhvbGRlcj0ndGl0bGU6J1xuICAgICAgICAvPjxiciAvPlxuICAgICAgICAgIGF1dGhvcjpcbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgIHZhbHVlPXthdXRob3J9XG4gICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRBdXRob3IodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICBkYXRhLXRlc3RpZD0nYXV0aG9yLWlucHV0JyBwbGFjZWhvbGRlcj0nYXV0aG9yOidcbiAgICAgICAgLz48YnIgLz5cbiAgICAgICAgICB1cmw6XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICB2YWx1ZT17dXJsfVxuICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VXJsKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgZGF0YS10ZXN0aWQ9J3VybC1pbnB1dCcgcGxhY2Vob2xkZXI9J3VybDonXG4gICAgICAgIC8+XG4gICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPmNyZWF0ZTwvYnV0dG9uPlxuICAgICAgPC9mb3JtPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEJsb2dGb3JtXG4iXSwiZmlsZSI6Ii9Vc2Vycy9hcnZvL2Z1bGxzdGFjay9vc2E1L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL0Jsb2dGb3JtLmpzeCJ9