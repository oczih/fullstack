import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c26996b2"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=c26996b2"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Blog from "/src/components/Blog.jsx";
import Notification from "/src/components/Notification.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
import Footer from "/src/components/Footer.jsx";
import Togglable from "/src/components/Togglable.jsx";
import LoginForm from "/src/components/LoginForm.jsx";
import BlogForm from "/src/components/BlogForm.jsx";
import __vite__cjsImport12_propTypes from "/node_modules/.vite/deps/prop-types.js?v=c26996b2"; const PropTypes = __vite__cjsImport12_propTypes.__esModule ? __vite__cjsImport12_propTypes.default : __vite__cjsImport12_propTypes;
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [user, setUser] = useState(null);
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState(null);
  const [newBlog, setNewBlog] = useState("");
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const [loginVisible, setLoginVisible] = useState(false);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  useEffect(() => {
    blogService.getAll().then(
      (blogs2) => setBlogs(blogs2)
    );
  }, []);
  const addBlog = (blogObject) => {
    blogService.create(blogObject).then((returnedBlog) => {
      setBlogs(blogs.concat(returnedBlog));
    });
  };
  const handleBlogChange = (event) => {
    setNewBlog(event.target.value);
  };
  const handleLikeChange = (id) => {
    const blog = blogs.find((b) => b.id === id);
    const changedBlog = {
      ...blog,
      likes: blog.likes + 1,
      user: blog.user ? blog.user.id : null
    };
    blogService.update(id.trim(), changedBlog).then((returnedBlog) => {
      const updatedBlog = {
        ...returnedBlog,
        user: blog.user
      };
      setBlogs(blogs.map((b) => b.id !== id ? b : updatedBlog));
    }).catch((error) => {
      setErrorMessage(`Blog ${blog.title} couldn't be updated`);
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    });
  };
  const handleBlogDelete = (id) => {
    const blog = blogs.find((b) => b.id === id);
    if (window.confirm(`Remove blog ${blog.title} by ${blog.author}`)) {
      blogService.remove(id).then(() => {
        setBlogs(blogs.filter((b) => b.id !== id));
      }).catch((error) => {
        setErrorMessage(`Blog ${blog.title} couldn't be removed`);
        setTimeout(() => {
          setErrorMessage(null);
        }, 5e3);
      });
    }
  };
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem(
        "loggedBlogappUser",
        JSON.stringify(user2)
      );
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      setErrorMessage("Wrong username or password");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  if (user === null) {
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 133,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Notification, { message: errorMessage }, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 134,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "show login", children: /* @__PURE__ */ jsxDEV(
        LoginForm,
        {
          handleSubmit: handleLogin,
          handleUsernameChange: ({ target }) => setUsername(target.value),
          handlePasswordChange: ({ target }) => setPassword(target.value),
          username,
          password,
          children: /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
            fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
            lineNumber: 142,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
          lineNumber: 136,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 135,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Footer, {}, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 145,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 132,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 152,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: errorMessage }, void 0, false, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 153,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: [
      user.name,
      " logged in"
    ] }, void 0, true, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 154,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => {
      window.localStorage.clear();
      setUser(null);
    }, children: "logout" }, void 0, false, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 154,
      columnNumber: 35
    }, this),
    /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "new blog", children: /* @__PURE__ */ jsxDEV(
      BlogForm,
      {
        createBlog: addBlog
      },
      void 0,
      false,
      {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 158,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 157,
      columnNumber: 7
    }, this),
    blogs.sort((a, b) => b.likes - a.likes).map(
      (blog) => /* @__PURE__ */ jsxDEV(
        Blog,
        {
          blog,
          handleLikeChange: () => handleLikeChange(blog.id),
          handleBlogDelete: () => handleBlogDelete(blog.id)
        },
        blog.id,
        false,
        {
          fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
          lineNumber: 163,
          columnNumber: 7
        },
        this
      )
    ),
    /* @__PURE__ */ jsxDEV(Footer, {}, void 0, false, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 166,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx",
    lineNumber: 151,
    columnNumber: 5
  }, this);
};
_s(App, "io9PxMWxJh/0LvHIGX++YLwh0FE=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/arvo/fullstack/osa5/bloglist-frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUhROzs7Ozs7Ozs7Ozs7Ozs7OztBQWpIUixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGVBQWU7QUFDdEIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJZCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDZSxVQUFVQyxXQUFXLElBQUloQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDaUIsTUFBTUMsT0FBTyxJQUFJbEIsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQ21CLFVBQVVDLFdBQVcsSUFBSXBCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNxQixjQUFjQyxlQUFlLElBQUl0QixTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDdUIsU0FBU0MsVUFBVSxJQUFJeEIsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ3lCLE9BQU9DLFFBQVEsSUFBSTFCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUMyQixRQUFRQyxTQUFTLElBQUk1QixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDNkIsS0FBS0MsTUFBTSxJQUFJOUIsU0FBUyxFQUFFO0FBQ2pDLFFBQU0sQ0FBQytCLGNBQWNDLGVBQWUsSUFBSWhDLFNBQVMsS0FBSztBQUV0REMsWUFBVSxNQUFNO0FBQ2QsVUFBTWdDLGlCQUFpQkMsT0FBT0MsYUFBYUMsUUFBUSxtQkFBbUI7QUFDdEUsUUFBSUgsZ0JBQWdCO0FBQ2xCLFlBQU1oQixRQUFPb0IsS0FBS0MsTUFBTUwsY0FBYztBQUN0Q2YsY0FBUUQsS0FBSTtBQUNaYixrQkFBWW1DLFNBQVN0QixNQUFLdUIsS0FBSztBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTHZDLFlBQVUsTUFBTTtBQUNkRyxnQkFBWXFDLE9BQU8sRUFBRUM7QUFBQUEsTUFBSyxDQUFBN0IsV0FDeEJDLFNBQVVELE1BQU07QUFBQSxJQUNsQjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBQ0wsUUFBTThCLFVBQVVBLENBQUNDLGVBQWU7QUFDOUJ4QyxnQkFDR3lDLE9BQU9ELFVBQVUsRUFDakJGLEtBQUssQ0FBQUksaUJBQWdCO0FBQ3BCaEMsZUFBU0QsTUFBTWtDLE9BQU9ELFlBQVksQ0FBQztBQUFBLElBQ3JDLENBQUM7QUFBQSxFQUNMO0FBRUEsUUFBTUUsbUJBQW1CQSxDQUFDQyxVQUFVO0FBQ2xDekIsZUFBV3lCLE1BQU1DLE9BQU9DLEtBQUs7QUFBQSxFQUMvQjtBQUVBLFFBQU1DLG1CQUFtQkEsQ0FBQUMsT0FBTTtBQUM3QixVQUFNQyxPQUFPekMsTUFBTTBDLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUgsT0FBT0EsRUFBRTtBQUN4QyxVQUFNSSxjQUFjO0FBQUEsTUFDbEIsR0FBR0g7QUFBQUEsTUFDSEksT0FBT0osS0FBS0ksUUFBUTtBQUFBLE1BQ3BCekMsTUFBTXFDLEtBQUtyQyxPQUFPcUMsS0FBS3JDLEtBQUtvQyxLQUFLO0FBQUEsSUFDbkM7QUFDQWpELGdCQUNHdUQsT0FBT04sR0FBR08sS0FBSyxHQUFHSCxXQUFXLEVBQzdCZixLQUFLLENBQUFJLGlCQUFnQjtBQUNwQixZQUFNZSxjQUFjO0FBQUEsUUFDbEIsR0FBR2Y7QUFBQUEsUUFDSDdCLE1BQU1xQyxLQUFLckM7QUFBQUEsTUFDYjtBQUNBSCxlQUFTRCxNQUFNaUQsSUFBSSxDQUFBTixNQUFNQSxFQUFFSCxPQUFPQSxLQUFLRyxJQUFJSyxXQUFZLENBQUM7QUFBQSxJQUMxRCxDQUFDLEVBQ0FFLE1BQU0sQ0FBQUMsVUFBUztBQUNkMUMsc0JBQWdCLFFBQVFnQyxLQUFLN0IsS0FBSyxzQkFBc0I7QUFDeER3QyxpQkFBVyxNQUFNO0FBQ2YzQyx3QkFBZ0IsSUFBSTtBQUFBLE1BQ3RCLEdBQUcsR0FBSTtBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0w7QUFDQSxRQUFNNEMsbUJBQW1CQSxDQUFBYixPQUFNO0FBQzdCLFVBQU1DLE9BQU96QyxNQUFNMEMsS0FBSyxDQUFBQyxNQUFLQSxFQUFFSCxPQUFPQSxFQUFFO0FBQ3hDLFFBQUluQixPQUFPaUMsUUFBUSxlQUFlYixLQUFLN0IsS0FBSyxPQUFPNkIsS0FBSzNCLE1BQU0sRUFBRSxHQUFHO0FBQ2pFdkIsa0JBQ0dnRSxPQUFPZixFQUFFLEVBQ1RYLEtBQUssTUFBTTtBQUNWNUIsaUJBQVNELE1BQU13RCxPQUFPLENBQUFiLE1BQUtBLEVBQUVILE9BQU9BLEVBQUUsQ0FBQztBQUFBLE1BQ3pDLENBQUMsRUFDQVUsTUFBTSxDQUFBQyxVQUFTO0FBQ2QxQyx3QkFBZ0IsUUFBUWdDLEtBQUs3QixLQUFLLHNCQUFzQjtBQUN4RHdDLG1CQUFXLE1BQU07QUFDZjNDLDBCQUFnQixJQUFJO0FBQUEsUUFDdEIsR0FBRyxHQUFJO0FBQUEsTUFDVCxDQUFDO0FBQUEsSUFDTDtBQUFBLEVBQ0Y7QUFDQSxRQUFNZ0QsY0FBYyxPQUFPckIsVUFBVTtBQUNuQ0EsVUFBTXNCLGVBQWU7QUFFckIsUUFBSTtBQUNGLFlBQU10RCxRQUFPLE1BQU1aLGFBQWFtRSxNQUFNO0FBQUEsUUFDcEN6RDtBQUFBQSxRQUFVSTtBQUFBQSxNQUNaLENBQUM7QUFDRGUsYUFBT0MsYUFBYXNDO0FBQUFBLFFBQ2xCO0FBQUEsUUFBcUJwQyxLQUFLcUMsVUFBVXpELEtBQUk7QUFBQSxNQUMxQztBQUNBYixrQkFBWW1DLFNBQVN0QixNQUFLdUIsS0FBSztBQUMvQnRCLGNBQVFELEtBQUk7QUFDWkQsa0JBQVksRUFBRTtBQUNkSSxrQkFBWSxFQUFFO0FBQUEsSUFDaEIsU0FBU3VELFdBQVc7QUFDbEJyRCxzQkFBZ0IsNEJBQTRCO0FBQzVDMkMsaUJBQVcsTUFBTTtBQUNmM0Msd0JBQWdCLElBQUk7QUFBQSxNQUN0QixHQUFHLEdBQUk7QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUdBLE1BQUlMLFNBQVMsTUFBTTtBQUNqQixXQUNFLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUztBQUFBLE1BQ1QsdUJBQUMsZ0JBQWEsU0FBU0ksZ0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0M7QUFBQSxNQUNwQyx1QkFBQyxhQUFVLGFBQVksY0FDckI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLGNBQWNpRDtBQUFBQSxVQUNkLHNCQUFzQixDQUFDLEVBQUVwQixPQUFPLE1BQU1sQyxZQUFZa0MsT0FBT0MsS0FBSztBQUFBLFVBQzlELHNCQUFzQixDQUFDLEVBQUVELE9BQU8sTUFBTTlCLFlBQVk4QixPQUFPQyxLQUFLO0FBQUEsVUFDOUQ7QUFBQSxVQUNBO0FBQUEsVUFDQSxpQ0FBQyxZQUFPLE1BQUssVUFBUyxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQTtBQUFBLFFBTjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTztBQUFBLFNBYlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNBO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQUEsSUFDVCx1QkFBQyxnQkFBYSxTQUFTOUIsZ0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0M7QUFBQSxJQUNwQyx1QkFBQyxPQUFHSjtBQUFBQSxXQUFLMkQ7QUFBQUEsTUFBSztBQUFBLFNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QjtBQUFBLElBQUksdUJBQUMsWUFBTyxTQUFTLE1BQU07QUFBQzFDLGFBQU9DLGFBQWEwQyxNQUFNO0FBQzVFM0QsY0FBUSxJQUFJO0FBQUEsSUFBQyxHQUNiLHNCQUYwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRXBCO0FBQUEsSUFDUix1QkFBQyxhQUFVLGFBQVksWUFDckI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFlBQVl5QjtBQUFBQTtBQUFBQSxNQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUNzQixLQUZ4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0k7QUFBQSxJQUVIOUIsTUFBTWlFLEtBQUssQ0FBQ0MsR0FBR3ZCLE1BQU1BLEVBQUVFLFFBQVFxQixFQUFFckIsS0FBSyxFQUFFSTtBQUFBQSxNQUFJLENBQUFSLFNBQzNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFBbUI7QUFBQSxVQUNsQixrQkFBa0IsTUFBTUYsaUJBQWlCRSxLQUFLRCxFQUFFO0FBQUEsVUFBRyxrQkFBa0IsTUFBTWEsaUJBQWlCWixLQUFLRCxFQUFFO0FBQUE7QUFBQSxRQUQxRkMsS0FBS0Q7QUFBQUEsUUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUN1RztBQUFBLElBQ3pHO0FBQUEsSUFDQSx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTztBQUFBLE9BZlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdCQTtBQUVKO0FBQUN6QyxHQTNJS0QsS0FBRztBQUFBcUUsS0FBSHJFO0FBNklOLGVBQWVBO0FBQUcsSUFBQXFFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkJsb2ciLCJOb3RpZmljYXRpb24iLCJibG9nU2VydmljZSIsImxvZ2luU2VydmljZSIsIkZvb3RlciIsIlRvZ2dsYWJsZSIsIkxvZ2luRm9ybSIsIkJsb2dGb3JtIiwiUHJvcFR5cGVzIiwiQXBwIiwiX3MiLCJibG9ncyIsInNldEJsb2dzIiwidXNlcm5hbWUiLCJzZXRVc2VybmFtZSIsInVzZXIiLCJzZXRVc2VyIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImVycm9yTWVzc2FnZSIsInNldEVycm9yTWVzc2FnZSIsIm5ld0Jsb2ciLCJzZXROZXdCbG9nIiwidGl0bGUiLCJzZXRUaXRsZSIsImF1dGhvciIsInNldEF1dGhvciIsInVybCIsInNldFVybCIsImxvZ2luVmlzaWJsZSIsInNldExvZ2luVmlzaWJsZSIsImxvZ2dlZFVzZXJKU09OIiwid2luZG93IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsIkpTT04iLCJwYXJzZSIsInNldFRva2VuIiwidG9rZW4iLCJnZXRBbGwiLCJ0aGVuIiwiYWRkQmxvZyIsImJsb2dPYmplY3QiLCJjcmVhdGUiLCJyZXR1cm5lZEJsb2ciLCJjb25jYXQiLCJoYW5kbGVCbG9nQ2hhbmdlIiwiZXZlbnQiLCJ0YXJnZXQiLCJ2YWx1ZSIsImhhbmRsZUxpa2VDaGFuZ2UiLCJpZCIsImJsb2ciLCJmaW5kIiwiYiIsImNoYW5nZWRCbG9nIiwibGlrZXMiLCJ1cGRhdGUiLCJ0cmltIiwidXBkYXRlZEJsb2ciLCJtYXAiLCJjYXRjaCIsImVycm9yIiwic2V0VGltZW91dCIsImhhbmRsZUJsb2dEZWxldGUiLCJjb25maXJtIiwicmVtb3ZlIiwiZmlsdGVyIiwiaGFuZGxlTG9naW4iLCJwcmV2ZW50RGVmYXVsdCIsImxvZ2luIiwic2V0SXRlbSIsInN0cmluZ2lmeSIsImV4Y2VwdGlvbiIsIm5hbWUiLCJjbGVhciIsInNvcnQiLCJhIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBCbG9nIGZyb20gJy4vY29tcG9uZW50cy9CbG9nJ1xuaW1wb3J0IE5vdGlmaWNhdGlvbiBmcm9tICcuL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uJ1xuaW1wb3J0IGJsb2dTZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvYmxvZ3MnXG5pbXBvcnQgbG9naW5TZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvbG9naW4nXG5pbXBvcnQgRm9vdGVyIGZyb20gJy4vY29tcG9uZW50cy9Gb290ZXInXG5pbXBvcnQgVG9nZ2xhYmxlIGZyb20gJy4vY29tcG9uZW50cy9Ub2dnbGFibGUnXG5pbXBvcnQgTG9naW5Gb3JtIGZyb20gJy4vY29tcG9uZW50cy9Mb2dpbkZvcm0nXG5pbXBvcnQgQmxvZ0Zvcm0gZnJvbSAnLi9jb21wb25lbnRzL0Jsb2dGb3JtJ1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJ1xuY29uc3QgQXBwID0gKCkgPT4ge1xuICBjb25zdCBbYmxvZ3MsIHNldEJsb2dzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbZXJyb3JNZXNzYWdlLCBzZXRFcnJvck1lc3NhZ2VdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW25ld0Jsb2csIHNldE5ld0Jsb2ddID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFthdXRob3IsIHNldEF1dGhvcl0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3VybCwgc2V0VXJsXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbbG9naW5WaXNpYmxlLCBzZXRMb2dpblZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBsb2dnZWRVc2VySlNPTiA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInKVxuICAgIGlmIChsb2dnZWRVc2VySlNPTikge1xuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9nZ2VkVXNlckpTT04pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGJsb2dzID0+XG4gICAgICBzZXRCbG9ncyggYmxvZ3MgKVxuICAgIClcbiAgfSwgW10pXG4gIGNvbnN0IGFkZEJsb2cgPSAoYmxvZ09iamVjdCkgPT4ge1xuICAgIGJsb2dTZXJ2aWNlXG4gICAgICAuY3JlYXRlKGJsb2dPYmplY3QpXG4gICAgICAudGhlbihyZXR1cm5lZEJsb2cgPT4ge1xuICAgICAgICBzZXRCbG9ncyhibG9ncy5jb25jYXQocmV0dXJuZWRCbG9nKSlcbiAgICAgIH0pXG4gIH1cblxuICBjb25zdCBoYW5kbGVCbG9nQ2hhbmdlID0gKGV2ZW50KSA9PiB7XG4gICAgc2V0TmV3QmxvZyhldmVudC50YXJnZXQudmFsdWUpXG4gIH1cblxuICBjb25zdCBoYW5kbGVMaWtlQ2hhbmdlID0gaWQgPT4ge1xuICAgIGNvbnN0IGJsb2cgPSBibG9ncy5maW5kKGIgPT4gYi5pZCA9PT0gaWQpXG4gICAgY29uc3QgY2hhbmdlZEJsb2cgPSB7XG4gICAgICAuLi5ibG9nLFxuICAgICAgbGlrZXM6IGJsb2cubGlrZXMgKyAxLFxuICAgICAgdXNlcjogYmxvZy51c2VyID8gYmxvZy51c2VyLmlkIDogbnVsbFxuICAgIH1cbiAgICBibG9nU2VydmljZVxuICAgICAgLnVwZGF0ZShpZC50cmltKCksIGNoYW5nZWRCbG9nKVxuICAgICAgLnRoZW4ocmV0dXJuZWRCbG9nID0+IHtcbiAgICAgICAgY29uc3QgdXBkYXRlZEJsb2cgPSB7XG4gICAgICAgICAgLi4ucmV0dXJuZWRCbG9nLFxuICAgICAgICAgIHVzZXI6IGJsb2cudXNlclxuICAgICAgICB9XG4gICAgICAgIHNldEJsb2dzKGJsb2dzLm1hcChiID0+IChiLmlkICE9PSBpZCA/IGIgOiB1cGRhdGVkQmxvZykpKVxuICAgICAgfSlcbiAgICAgIC5jYXRjaChlcnJvciA9PiB7XG4gICAgICAgIHNldEVycm9yTWVzc2FnZShgQmxvZyAke2Jsb2cudGl0bGV9IGNvdWxkbid0IGJlIHVwZGF0ZWRgKVxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICBzZXRFcnJvck1lc3NhZ2UobnVsbClcbiAgICAgICAgfSwgNTAwMClcbiAgICAgIH0pXG4gIH1cbiAgY29uc3QgaGFuZGxlQmxvZ0RlbGV0ZSA9IGlkID0+IHtcbiAgICBjb25zdCBibG9nID0gYmxvZ3MuZmluZChiID0+IGIuaWQgPT09IGlkKVxuICAgIGlmICh3aW5kb3cuY29uZmlybShgUmVtb3ZlIGJsb2cgJHtibG9nLnRpdGxlfSBieSAke2Jsb2cuYXV0aG9yfWApKSB7XG4gICAgICBibG9nU2VydmljZVxuICAgICAgICAucmVtb3ZlKGlkKVxuICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgICAgc2V0QmxvZ3MoYmxvZ3MuZmlsdGVyKGIgPT4gYi5pZCAhPT0gaWQpKVxuICAgICAgICB9KVxuICAgICAgICAuY2F0Y2goZXJyb3IgPT4ge1xuICAgICAgICAgIHNldEVycm9yTWVzc2FnZShgQmxvZyAke2Jsb2cudGl0bGV9IGNvdWxkbid0IGJlIHJlbW92ZWRgKVxuICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpXG4gICAgICAgICAgfSwgNTAwMClcbiAgICAgICAgfSlcbiAgICB9XG4gIH1cbiAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luU2VydmljZS5sb2dpbih7XG4gICAgICAgIHVzZXJuYW1lLCBwYXNzd29yZCxcbiAgICAgIH0pXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXG4gICAgICAgICdsb2dnZWRCbG9nYXBwVXNlcicsIEpTT04uc3RyaW5naWZ5KHVzZXIpXG4gICAgICApXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgICAgc2V0VXNlcih1c2VyKVxuICAgICAgc2V0VXNlcm5hbWUoJycpXG4gICAgICBzZXRQYXNzd29yZCgnJylcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHNldEVycm9yTWVzc2FnZSgnV3JvbmcgdXNlcm5hbWUgb3IgcGFzc3dvcmQnKVxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldEVycm9yTWVzc2FnZShudWxsKVxuICAgICAgfSwgNTAwMClcbiAgICB9XG4gIH1cblxuXG4gIGlmICh1c2VyID09PSBudWxsKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXY+XG4gICAgICAgIDxoMj5ibG9nczwvaDI+XG4gICAgICAgIDxOb3RpZmljYXRpb24gbWVzc2FnZT17ZXJyb3JNZXNzYWdlfS8+XG4gICAgICAgIDxUb2dnbGFibGUgYnV0dG9uTGFiZWw9J3Nob3cgbG9naW4nPlxuICAgICAgICAgIDxMb2dpbkZvcm1cbiAgICAgICAgICAgIGhhbmRsZVN1Ym1pdD17aGFuZGxlTG9naW59XG4gICAgICAgICAgICBoYW5kbGVVc2VybmFtZUNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVzZXJuYW1lKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBoYW5kbGVQYXNzd29yZENoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFBhc3N3b3JkKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICB1c2VybmFtZT17dXNlcm5hbWV9XG4gICAgICAgICAgICBwYXNzd29yZD17cGFzc3dvcmR9PlxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+bG9naW48L2J1dHRvbj5cbiAgICAgICAgICA8L0xvZ2luRm9ybT5cbiAgICAgICAgPC9Ub2dnbGFibGU+XG4gICAgICAgIDxGb290ZXIgLz5cbiAgICAgIDwvZGl2PlxuICAgIClcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMj5ibG9nczwvaDI+XG4gICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e2Vycm9yTWVzc2FnZX0vPlxuICAgICAgPHA+e3VzZXIubmFtZX0gbG9nZ2VkIGluPC9wPjxidXR0b24gb25DbGljaz17KCkgPT4ge3dpbmRvdy5sb2NhbFN0b3JhZ2UuY2xlYXIoKVxuICAgICAgICBzZXRVc2VyKG51bGwpfVxuICAgICAgfT5sb2dvdXQ8L2J1dHRvbj5cbiAgICAgIDxUb2dnbGFibGUgYnV0dG9uTGFiZWw9J25ldyBibG9nJz5cbiAgICAgICAgPEJsb2dGb3JtXG4gICAgICAgICAgY3JlYXRlQmxvZz17YWRkQmxvZ31cbiAgICAgICAgLz48L1RvZ2dsYWJsZT5cblxuICAgICAge2Jsb2dzLnNvcnQoKGEsIGIpID0+IGIubGlrZXMgLSBhLmxpa2VzKS5tYXAoYmxvZyA9PlxuICAgICAgICA8QmxvZyBrZXk9e2Jsb2cuaWR9IGJsb2c9e2Jsb2d9XG4gICAgICAgICAgaGFuZGxlTGlrZUNoYW5nZT17KCkgPT4gaGFuZGxlTGlrZUNoYW5nZShibG9nLmlkKX0gaGFuZGxlQmxvZ0RlbGV0ZT17KCkgPT4gaGFuZGxlQmxvZ0RlbGV0ZShibG9nLmlkKX0gLz5cbiAgICAgICl9XG4gICAgICA8Rm9vdGVyIC8+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwIl0sImZpbGUiOiIvVXNlcnMvYXJ2by9mdWxsc3RhY2svb3NhNS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvQXBwLmpzeCJ9