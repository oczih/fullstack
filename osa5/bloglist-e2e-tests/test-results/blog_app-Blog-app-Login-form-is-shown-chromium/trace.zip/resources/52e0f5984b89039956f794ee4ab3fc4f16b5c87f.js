import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c26996b2"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Blog.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import Togglable from "/src/components/Togglable.jsx";
const Blog = ({ blog, handleLikeChange, handleBlogDelete }) => {
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "blog", style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      blog.title,
      " ",
      blog.author,
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 32,
        columnNumber: 38
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 32,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "view", children: [
      blog.url,
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 35,
        columnNumber: 21
      }, this),
      blog.likes,
      " likes ",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLikeChange, "data-testid": "like-count", children: "like" }, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 36,
        columnNumber: 30
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 36,
        columnNumber: 103
      }, this),
      blog.user ? blog.user.name : "",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 37,
        columnNumber: 44
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleBlogDelete, children: "remove" }, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 38,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 34,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 33,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 31,
    columnNumber: 5
  }, this);
};
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Blog.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWXFDOzs7Ozs7Ozs7Ozs7Ozs7O0FBWnJDLE9BQU9BLGVBQWU7QUFFdEIsTUFBTUMsT0FBT0EsQ0FBQyxFQUFFQyxNQUFNQyxrQkFBa0JDLGlCQUFpQixNQUFNO0FBQzdELFFBQU1DLFlBQVk7QUFBQSxJQUNoQkMsWUFBWTtBQUFBLElBQ1pDLGFBQWE7QUFBQSxJQUNiQyxRQUFRO0FBQUEsSUFDUkMsYUFBYTtBQUFBLElBQ2JDLGNBQWM7QUFBQSxFQUNoQjtBQUNBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFFBQU8sT0FBT0wsV0FDM0I7QUFBQSwyQkFBQyxTQUFLSDtBQUFBQSxXQUFLUztBQUFBQSxNQUFNO0FBQUEsTUFBRVQsS0FBS1U7QUFBQUEsTUFBTyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLFNBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0M7QUFBQSxJQUNwQyx1QkFBQyxTQUNDLGlDQUFDLGFBQVUsYUFBWSxRQUNwQlY7QUFBQUEsV0FBS1c7QUFBQUEsTUFBSSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQ1pYLEtBQUtZO0FBQUFBLE1BQU07QUFBQSxNQUFPLHVCQUFDLFlBQU8sU0FBU1gsa0JBQWtCLGVBQVksY0FBYSxvQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRTtBQUFBLE1BQVMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxNQUM5RkQsS0FBS2EsT0FBT2IsS0FBS2EsS0FBS0MsT0FBTztBQUFBLE1BQUcsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxNQUNwQyx1QkFBQyxZQUFPLFNBQVNaLGtCQUFrQixzQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLFNBSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLE9BVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBO0FBRUo7QUFBQ2EsS0F0QktoQjtBQXdCTixlQUFlQTtBQUFJLElBQUFnQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiVG9nZ2xhYmxlIiwiQmxvZyIsImJsb2ciLCJoYW5kbGVMaWtlQ2hhbmdlIiwiaGFuZGxlQmxvZ0RlbGV0ZSIsImJsb2dTdHlsZSIsInBhZGRpbmdUb3AiLCJwYWRkaW5nTGVmdCIsImJvcmRlciIsImJvcmRlcldpZHRoIiwibWFyZ2luQm90dG9tIiwidGl0bGUiLCJhdXRob3IiLCJ1cmwiLCJsaWtlcyIsInVzZXIiLCJuYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgVG9nZ2xhYmxlIGZyb20gJy4vVG9nZ2xhYmxlJ1xuXG5jb25zdCBCbG9nID0gKHsgYmxvZywgaGFuZGxlTGlrZUNoYW5nZSwgaGFuZGxlQmxvZ0RlbGV0ZSB9KSA9PiB7XG4gIGNvbnN0IGJsb2dTdHlsZSA9IHtcbiAgICBwYWRkaW5nVG9wOiAxMCxcbiAgICBwYWRkaW5nTGVmdDogMixcbiAgICBib3JkZXI6ICdzb2xpZCcsXG4gICAgYm9yZGVyV2lkdGg6IDEsXG4gICAgbWFyZ2luQm90dG9tOiA1XG4gIH1cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT0nYmxvZycgc3R5bGU9e2Jsb2dTdHlsZX0+XG4gICAgICA8ZGl2PntibG9nLnRpdGxlfSB7YmxvZy5hdXRob3J9PGJyLz48L2Rpdj5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxUb2dnbGFibGUgYnV0dG9uTGFiZWw9J3ZpZXcnPlxuICAgICAgICAgIHtibG9nLnVybH08YnIvPlxuICAgICAgICAgIHtibG9nLmxpa2VzfSBsaWtlcyA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUxpa2VDaGFuZ2V9IGRhdGEtdGVzdGlkPVwibGlrZS1jb3VudFwiPmxpa2U8L2J1dHRvbj48YnIvPlxuICAgICAgICAgIHtibG9nLnVzZXIgPyBibG9nLnVzZXIubmFtZSA6ICcnfTxici8+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVCbG9nRGVsZXRlfT5yZW1vdmU8L2J1dHRvbj5cbiAgICAgICAgPC9Ub2dnbGFibGU+XG4gICAgICA8L2Rpdj5cblxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEJsb2ciXSwiZmlsZSI6Ii9Vc2Vycy9hcnZvL2Z1bGxzdGFjay9vc2E1L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL0Jsb2cuanN4In0=