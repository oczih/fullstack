import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c26996b2"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/LoginForm.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=c26996b2"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
const LoginForm = ({
  handleSubmit,
  handleUsernameChange,
  handlePasswordChange,
  username,
  password
}) => {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Login" }, void 0, false, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "username",
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-testid": "username",
            value: username,
            onChange: handleUsernameChange
          },
          void 0,
          false,
          {
            fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/LoginForm.jsx",
            lineNumber: 36,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 34,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "password",
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            "data-testid": "password",
            type: "password",
            value: password,
            onChange: handlePasswordChange
          },
          void 0,
          false,
          {
            fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/LoginForm.jsx",
            lineNumber: 44,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 42,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 51,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 33,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/LoginForm.jsx",
    lineNumber: 30,
    columnNumber: 5
  }, this);
};
_c = LoginForm;
LoginForm.propTypes = {
  handleSubmit: PropTypes.func.isRequired,
  handleUsernameChange: PropTypes.func.isRequired,
  handlePasswordChange: PropTypes.func.isRequired,
  username: PropTypes.string.isRequired,
  password: PropTypes.string.isRequired
};
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/LoginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/LoginForm.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV007Ozs7Ozs7Ozs7Ozs7Ozs7QUFYTixPQUFPQSxlQUFlO0FBRXRCLE1BQU1DLFlBQVlBLENBQUM7QUFBQSxFQUNqQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQ0osU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUVULHVCQUFDLFVBQUssVUFBVUosY0FDZDtBQUFBLDZCQUFDLFNBQUc7QUFBQTtBQUFBLFFBRUY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGVBQVk7QUFBQSxZQUNaLE9BQU9HO0FBQUFBLFlBQ1AsVUFBVUY7QUFBQUE7QUFBQUEsVUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHaUM7QUFBQSxXQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLFFBRUY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGVBQVk7QUFBQSxZQUNaLE1BQUs7QUFBQSxZQUNMLE9BQU9HO0FBQUFBLFlBQ1AsVUFBVUY7QUFBQUE7QUFBQUEsVUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJaUM7QUFBQSxXQU5uQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJCO0FBQUEsU0FsQjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkE7QUFBQSxPQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUJBO0FBRUo7QUFBQ0csS0FqQ0tOO0FBa0NOQSxVQUFVTyxZQUFZO0FBQUEsRUFDcEJOLGNBQWNGLFVBQVVTLEtBQUtDO0FBQUFBLEVBQzdCUCxzQkFBc0JILFVBQVVTLEtBQUtDO0FBQUFBLEVBQ3JDTixzQkFBc0JKLFVBQVVTLEtBQUtDO0FBQUFBLEVBQ3JDTCxVQUFVTCxVQUFVVyxPQUFPRDtBQUFBQSxFQUMzQkosVUFBVU4sVUFBVVcsT0FBT0Q7QUFDN0I7QUFDQSxlQUFlVDtBQUFTLElBQUFNO0FBQUFLLGFBQUFMLElBQUEiLCJuYW1lcyI6WyJQcm9wVHlwZXMiLCJMb2dpbkZvcm0iLCJoYW5kbGVTdWJtaXQiLCJoYW5kbGVVc2VybmFtZUNoYW5nZSIsImhhbmRsZVBhc3N3b3JkQ2hhbmdlIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsIl9jIiwicHJvcFR5cGVzIiwiZnVuYyIsImlzUmVxdWlyZWQiLCJzdHJpbmciLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJMb2dpbkZvcm0uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcydcblxuY29uc3QgTG9naW5Gb3JtID0gKHtcbiAgaGFuZGxlU3VibWl0LFxuICBoYW5kbGVVc2VybmFtZUNoYW5nZSxcbiAgaGFuZGxlUGFzc3dvcmRDaGFuZ2UsXG4gIHVzZXJuYW1lLFxuICBwYXNzd29yZFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDI+TG9naW48L2gyPlxuXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICB1c2VybmFtZVxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJ1c2VybmFtZVwiXG4gICAgICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVXNlcm5hbWVDaGFuZ2V9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgcGFzc3dvcmRcbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXNzd29yZENoYW5nZX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+bG9naW48L2J1dHRvbj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuTG9naW5Gb3JtLnByb3BUeXBlcyA9IHtcbiAgaGFuZGxlU3VibWl0OiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxuICBoYW5kbGVVc2VybmFtZUNoYW5nZTogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcbiAgaGFuZGxlUGFzc3dvcmRDaGFuZ2U6IFByb3BUeXBlcy5mdW5jLmlzUmVxdWlyZWQsXG4gIHVzZXJuYW1lOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gIHBhc3N3b3JkOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWRcbn1cbmV4cG9ydCBkZWZhdWx0IExvZ2luRm9ybSJdLCJmaWxlIjoiL1VzZXJzL2Fydm8vZnVsbHN0YWNrL29zYTUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTG9naW5Gb3JtLmpzeCJ9