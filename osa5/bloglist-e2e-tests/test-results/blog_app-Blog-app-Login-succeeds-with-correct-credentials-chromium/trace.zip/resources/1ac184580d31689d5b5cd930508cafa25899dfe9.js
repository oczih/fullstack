import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Togglable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=c26996b2"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Togglable.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=c26996b2"; const useState = __vite__cjsImport3_react["useState"]; const forwardRef = __vite__cjsImport3_react["forwardRef"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=c26996b2"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const Togglable = _s(forwardRef(_c = _s((props, ref) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = { display: visible ? "none" : "" };
  const showWhenVisible = { display: visible ? "" : "none" };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.buttonLabel }, void 0, false, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 36,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, className: "togglableContent", children: [
      props.children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "cancel" }, void 0, false, {
        fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Togglable.jsx",
        lineNumber: 41,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 38,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Togglable.jsx",
    lineNumber: 34,
    columnNumber: 5
  }, this);
}, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=")), "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c2 = Togglable;
Togglable.displayName = "Togglable";
Togglable.propTypes = {
  buttonLabel: PropTypes.string.isRequired
};
export default Togglable;
var _c, _c2;
$RefreshReg$(_c, "Togglable$forwardRef");
$RefreshReg$(_c2, "Togglable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Togglable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/arvo/fullstack/osa5/bloglist-frontend/src/components/Togglable.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQWhCUixTQUFTQSxVQUFVQyxrQkFBa0I7QUFDckMsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxZQUFTQyxHQUFHSCxXQUFVSSxLQUFBRCxHQUFDLENBQUNFLE9BQU9DLFFBQVE7QUFBQUgsS0FBQTtBQUMzQyxRQUFNLENBQUNJLFNBQVNDLFVBQVUsSUFBSVQsU0FBUyxLQUFLO0FBRTVDLFFBQU1VLGtCQUFrQixFQUFFQyxTQUFTSCxVQUFVLFNBQVMsR0FBRztBQUN6RCxRQUFNSSxrQkFBa0IsRUFBRUQsU0FBU0gsVUFBVSxLQUFLLE9BQU87QUFFekQsUUFBTUssbUJBQW1CQSxNQUFNO0FBQzdCSixlQUFXLENBQUNELE9BQU87QUFBQSxFQUNyQjtBQUVBLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFNBQUksT0FBT0UsaUJBQ1YsaUNBQUMsWUFBTyxTQUFTRyxrQkFBbUJQLGdCQUFNUSxlQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNELEtBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxPQUFPRixpQkFBaUIsV0FBVSxvQkFFcENOO0FBQUFBLFlBQU1TO0FBQUFBLE1BQ1AsdUJBQUMsWUFBTyxTQUFTRixrQkFBa0Isc0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxTQUgzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVKLEdBQUMsa0NBQUM7QUFBQUcsTUF0QkliO0FBd0JOQSxVQUFVYyxjQUFjO0FBRXhCZCxVQUFVZSxZQUFZO0FBQUEsRUFDcEJKLGFBQWFaLFVBQVVpQixPQUFPQztBQUNoQztBQUNBLGVBQWVqQjtBQUFTLElBQUFFLElBQUFXO0FBQUFLLGFBQUFoQixJQUFBO0FBQUFnQixhQUFBTCxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJmb3J3YXJkUmVmIiwiUHJvcFR5cGVzIiwiVG9nZ2xhYmxlIiwiX3MiLCJfYyIsInByb3BzIiwicmVmIiwidmlzaWJsZSIsInNldFZpc2libGUiLCJoaWRlV2hlblZpc2libGUiLCJkaXNwbGF5Iiwic2hvd1doZW5WaXNpYmxlIiwidG9nZ2xlVmlzaWJpbGl0eSIsImJ1dHRvbkxhYmVsIiwiY2hpbGRyZW4iLCJfYzIiLCJkaXNwbGF5TmFtZSIsInByb3BUeXBlcyIsInN0cmluZyIsImlzUmVxdWlyZWQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUb2dnbGFibGUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCBmb3J3YXJkUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5cbmNvbnN0IFRvZ2dsYWJsZSA9IGZvcndhcmRSZWYoKHByb3BzLCByZWYpID0+IHtcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgaGlkZVdoZW5WaXNpYmxlID0geyBkaXNwbGF5OiB2aXNpYmxlID8gJ25vbmUnIDogJycgfVxuICBjb25zdCBzaG93V2hlblZpc2libGUgPSB7IGRpc3BsYXk6IHZpc2libGUgPyAnJyA6ICdub25lJyB9XG5cbiAgY29uc3QgdG9nZ2xlVmlzaWJpbGl0eSA9ICgpID0+IHtcbiAgICBzZXRWaXNpYmxlKCF2aXNpYmxlKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdiBzdHlsZT17aGlkZVdoZW5WaXNpYmxlfSA+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlVmlzaWJpbGl0eX0+e3Byb3BzLmJ1dHRvbkxhYmVsfTwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IHN0eWxlPXtzaG93V2hlblZpc2libGV9IGNsYXNzTmFtZT1cInRvZ2dsYWJsZUNvbnRlbnRcIj5cblxuICAgICAgICB7cHJvcHMuY2hpbGRyZW59XG4gICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlVmlzaWJpbGl0eX0+Y2FuY2VsPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufSlcblxuVG9nZ2xhYmxlLmRpc3BsYXlOYW1lID0gJ1RvZ2dsYWJsZSdcblxuVG9nZ2xhYmxlLnByb3BUeXBlcyA9IHtcbiAgYnV0dG9uTGFiZWw6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZFxufVxuZXhwb3J0IGRlZmF1bHQgVG9nZ2xhYmxlIl0sImZpbGUiOiIvVXNlcnMvYXJ2by9mdWxsc3RhY2svb3NhNS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Ub2dnbGFibGUuanN4In0=